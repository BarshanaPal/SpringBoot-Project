package com.barshana.spring_data_jpa.delegate;

import com.barshana.spring_data_jpa.service.JobService;
import com.barshana.spring_data_jpa.model.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Component
public class JobDelegate {

    @Autowired
    JobService jobService;

    public List<Job> findAllJobs (){
        return jobService.findAllJobs();
    }

    public String addNewJob(Job job){
        return jobService.addNewJob(job);
    }

    public Job findJobById(Long id){
        return jobService.findJobById(id);
    }

    public  Job updateJob( Job job){
        return jobService.updateJob(job);
    }

    public String deleteJobById( Long id){
        return jobService.deleteJobById(id);
    }
}
