package com.barshana.spring_data_jpa.serviceimpl;

import com.barshana.spring_data_jpa.ds.JobDS;
import com.barshana.spring_data_jpa.model.Job;
import com.barshana.spring_data_jpa.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobServiceImpl implements JobService {

    @Autowired
    private JobDS jobDS;

    @Override
    public List<Job> findAllJobs() {
        return jobDS.findAllJobs();
    }

    @Override
    public String addNewJob(Job job) {
        return jobDS.addNewJob(job);
    }

    @Override
    public Job findJobById(Long id) {
        return jobDS.findJobById(id);
    }

    @Override
    public Job updateJob(Job job) {
        return jobDS.updateJob(job);
    }

    @Override
    public String deleteJobById(Long id) {
        return jobDS.deleteJobById(id);
    }
}
