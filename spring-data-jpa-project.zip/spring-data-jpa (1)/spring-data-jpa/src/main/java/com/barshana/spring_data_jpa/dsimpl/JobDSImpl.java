package com.barshana.spring_data_jpa.dsimpl;

import com.barshana.spring_data_jpa.repository.JobRepo;
import com.barshana.spring_data_jpa.ds.JobDS;
import com.barshana.spring_data_jpa.model.Job;
import com.barshana.spring_data_jpa.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class JobDSImpl implements JobDS {


    @Autowired
    private JobRepo jobRepo;

    @Override
    public List<Job> findAllJobs() {
        return jobRepo.findAll();
    }

    @Override
    public String addNewJob(Job job) {
        Job savedJob = null;
        try {
            savedJob = jobRepo.save(job);
        }catch (Exception e){
            return "Failed to Save %s".formatted(e.getMessage());
        }
        return Objects.nonNull(savedJob) ?  "Success" : "Failed to Save";
    }

    @Override
    public Job findJobById(Long id) {
        return jobRepo.findById(id).orElse(new Job());
    }

    @Override
    public Job updateJob(Job job) {
        return jobRepo.save(job);
    }

    @Override
    public String deleteJobById(Long id) {
        try {
            jobRepo.deleteById(id);
        }catch (Exception e){
            return "Failed to delete Job %s".formatted(e.getMessage());
        }
        return Objects.isNull(findJobById(id).getJobId()) ? "Success" : "Failed to delete JOB";
    }


}
