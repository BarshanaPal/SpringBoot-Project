package com.barshana.spring_data_jpa.ds;

import com.barshana.spring_data_jpa.model.Job;

import java.util.List;

public interface JobDS {

    List<Job> findAllJobs ();

    String addNewJob(Job job);

    Job findJobById(Long id);

    Job updateJob(Job job);

    String deleteJobById( Long id);

}
