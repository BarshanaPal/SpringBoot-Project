package com.barshana.spring_data_jpa.controller;

import com.barshana.spring_data_jpa.delegate.JobDelegate;
import com.barshana.spring_data_jpa.model.Job;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobPosts")
public class JobController {

    @Autowired
    JobDelegate jobDelegate;

    @GetMapping(path = "/findAllJobs" , produces = {"application/json"})
    public List<Job> findAllJobs (){
        return jobDelegate.findAllJobs();
    }

    @PostMapping(path = "/addNewJob", produces = {"application/json"})
    public String addNewJob(@RequestBody Job job){
      return  jobDelegate.addNewJob(job);
    }

    @GetMapping(path = "/findJobById" , produces = {"application/json"})
    public @ResponseBody Job findJobById(@RequestParam Long id){
      return jobDelegate.findJobById(id);
    }

    @PutMapping(path = "/updateJob" , produces = {"application/json"})
    public @ResponseBody Job updateJob(@RequestBody Job job){
        return jobDelegate.updateJob(job);
    }

    @DeleteMapping(path = "/deleteJobById" , produces = {"application/json"})
    public String deleteJobById(@RequestParam Long id){
        return jobDelegate.deleteJobById(id);
    }
}
