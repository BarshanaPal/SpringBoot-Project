package com.barshana.spring_data_jpa.service;

import com.barshana.spring_data_jpa.model.Job;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface JobService {

    List<Job> findAllJobs ();

    String addNewJob(Job job);

    Job findJobById(Long id);

    Job updateJob(Job job);

    String deleteJobById( Long id);
}
