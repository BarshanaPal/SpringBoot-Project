package com.barshana.spring_data_jpa.model;

import jakarta.persistence.*;

@Entity
@Table(name = "job")
public class Job {

    @Id
    @Column(name = "job_id")
    private Long jobId;

    @Column(name = "job_desc")
    private String jobDescription;

    @Column(name = "req_skill")
    private String requiredSkill;

    @Column(name = "location")
    private String location;

    public Long getJobId() {
        return jobId;
    }

    public void setJobId(Long jobId) {
        this.jobId = jobId;
    }

    public String getJobDescription() {
        return jobDescription;
    }

    public void setJobDescription(String jobDescription) {
        this.jobDescription = jobDescription;
    }

    public String getRequiredSkill() {
        return requiredSkill;
    }

    public void setRequiredSkill(String requiredSkill) {
        this.requiredSkill = requiredSkill;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Job{" +
                "jobId=" + jobId +
                ", jobDescription='" + jobDescription + '\'' +
                ", requiredSkill='" + requiredSkill + '\'' +
                ", location='" + location + '\'' +
                '}';
    }
}
