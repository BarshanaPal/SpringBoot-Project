package com.barshana.spring_data_jpa.repository;

import com.barshana.spring_data_jpa.model.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JobRepo extends JpaRepository<Job,Long> {
}
